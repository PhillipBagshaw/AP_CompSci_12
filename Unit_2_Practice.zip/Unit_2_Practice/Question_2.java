
public class Question_2{
    public static void main(String[] args){
        
        int i = 0;
        int numA = 0;
        int numB = 1;
        int total = 0;
        
        while(i <= 4000000){
            
            i = numA + numB;
            
            if(i % 2 == 0){
                total += i;
            }
            
            numA = numB;
            
            numB = i;
        }
        
        System.out.println("Total: " + total);
    }
}
