
public class Question_3{
    public static void main(String[] args){
        
        int i = 0;
        int totalA = 0;
        int totalB = 0;
        int total = 0;
        
        while(i <= 100){
            
            totalA = i;
            totalA = (int)Math.pow(totalA, 2);
            
            total += totalA;
            
            totalB += i;
            if(i == 100){
                totalB = (int)Math.pow(totalB, 2);
                total -= totalB;
            }
            
            i++;
        }
        
        System.out.println("Total: " + Math.abs(total));
    }
}
