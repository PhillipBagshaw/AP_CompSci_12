import java.util.Scanner;

public class Rock_Paper_Scissors{

    static Scanner sc = new Scanner(System.in);
    
    static final int rock = 1;
    static final int paper = 2;
    static final int scissors = 3;
    
    static final int win = 1;
    static final int loss = 2;
    static final int tie = 3;
    
    static String resp = "";

    public static void main(String[] args){

        int wins = 0;
        int losses = 0;
        int ties = 0;
        
        int p1;
        int cpu;
        
        System.out.println("RPS 1.0");
        
        System.out.println("****************************************");
        System.out.println();
        
        System.out.println("Good luck, human ...");
        
        resp = "y";
        
        while(playAgain()){
            
            System.out.println();
            
            System.out.print("What do you throw? [1] Rock, [2] Paper, [3] Scissors ");
            p1 = sc.nextInt();
            
            while(p1 > 3 || p1 < 1){
                System.out.println();
                
                System.out.println("That number falls outside the parameters I gave. Please, try again.");
                
                System.out.println();
                
                System.out.print("What do you throw? [1] Rock, [2] Paper, [3] Scissors ");
                p1 = sc.nextInt();
            }
            
            cpu = (int) (Math.random() * 3 + 1);
            
            System.out.println();
            
            printChoices(p1, cpu);
            int result = calculateWinner(p1, cpu);
            
            if(result == tie){
                System.out.println("A draw ... pretty good human!  I demand a rematch ...");
                
                ties++;
            }
            else if(result == loss){
                System.out.println("I win!  You are not a challenge for me ...");
                
                losses++;
            }
            else if(result == win){
                System.out.println("Whaaa?? ... You beat me?  RAGE!");
                
                wins++;
            }
            
            resp = "";
            
        }

        results(wins, losses, ties);
        
    }

    public static void printChoices(int p1, int cpu){

        if(p1 == rock){
            System.out.print("You threw Rock! ");
        }
        else if(p1 == paper){
            System.out.print("You threw Paper! ");
        }
        else if(p1 == scissors){
            System.out.print("You threw Scissors! ");
        }

        if(cpu == rock){
            System.out.println("I threw Rock! ");
        }
        else if(cpu == paper){
            System.out.println("I threw Paper! ");
        }
        else if(cpu == scissors){
            System.out.println("I threw Scissors! ");
        }
    }

    public static int calculateWinner(int p1, int cpu){
        if(p1 == cpu){
            return tie;
        }
        else if(p1 == rock && cpu == scissors || p1 == paper && cpu == rock || p1 == scissors && cpu == paper){
            return win;
        }
        else{
            return loss;
        }
    }

    public static boolean playAgain(){
        if(resp.equals("Y") || resp.equals("y")){
            return true;
        }
        
        System.out.println();
        
        System.out.print("Do you want to play again? [y,n]: ");
        resp = sc.next();

        if(resp.equals("Y") || resp.equals("y")){
            return true;
        }
        else{
            return false;
        }
    }

    public static void results(int wins, int losses, int ties){
        System.out.println();
        
        System.out.println("Good game!");
        
        System.out.println("****************************************");
        
        System.out.println("Wins: " + wins);
        System.out.println("Losses: " + losses);
        System.out.println("Ties: " + ties);
    }
}
