
public class Question_1{
    public static void main(String[] args){
        
        int i = 0;
        int total = 0;
        
        while(i < 1000){
            if(i % 3 == 0 || i % 5 == 0){
                total += i;
            }
            
            i++;
        }
        
        System.out.println("Total: " + total);
    }
}
