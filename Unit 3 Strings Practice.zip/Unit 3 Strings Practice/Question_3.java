
public class Question_3{
    public static void main(String[] args){
        System.out.println(convert(15));
    }
    
    static String convert(int x){
        
        String newX = "";
        int factor = 0;
        
        while(factor > 0){
            
            int a = x % 2;
            factor = x/2;
            
            newX = a + newX;
        }
        
        return newX;
    }
}
