
public class Question_1{
    public static void main(String[] args){
        
        String a = read("I have a pen, I have a apple");
        System.out.println(a);
        
    }
    
    static String read(String str){
        String objectA = "";
        String objectB = "";
        
        str = str.replace(" ", "");
        str = str.toLowerCase();
        
        for(int i = 0; i < str.length(); i++){
            if(i == 0 && str.substring(i, i+6).equals("ihavea")){
                objectA = str.substring(i+6, str.lastIndexOf(",ihavea"));
            }
            
            if((i > 0 && i < str.length()-7) && str.substring(i, i+7).equals(",ihavea")){
                objectB = str.substring(i+7, str.length());
            }
        }
        
        return "Uh! " + objectB + objectA + ".";
    }
}
