
public class Question_2
{
    public static void main(String[] args){

        String a = read("A man a plan a canal panama");
        System.out.println(a);

    }

    static String read(String str){

        str = str.replace(" ", "");
        str = str.toLowerCase();

        String newA = str;

        String newB = "";

        for(int i = str.length(); i > 0; i--){

            String n = str.substring(i-1, i);

            newB += n;
        }

        if(newA.equals(newB)) return "Is a palindrome.";

        else return "Is not a palindrome.";
    }
}
