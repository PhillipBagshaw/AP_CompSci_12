
public class Question_4{
    public static void main(String[] args){
        
        System.out.println(pigLatin("Play Starcraft"));
        
    }
    
    static String pigLatin(String str){
        
        str = " " + str.toLowerCase() + " ";
        
        int start = 0;
        int finish = 0;
        
        int n = 0;
        
        String strNew = "";
        
        for(int i = 0; i < str.length(); i++){
            
            start = i;
            n = i;
            
            while(n < str.length() && Character.isLetter(str.charAt(n))){
                
                n++;
            }
            
            finish = n;
            
            if(start != 0 && !Character.isLetter(str.charAt(start-1))){
                strNew += str.substring(start+1, finish) + str.charAt(start) + "ay ";
            }
        }
        
        return strNew;
    }
}
