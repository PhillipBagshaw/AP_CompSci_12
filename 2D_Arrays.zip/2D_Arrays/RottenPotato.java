
public class RottenPotato{
    public static void main(String[] args){
        
        int[][] ratings = {{4, 6, 2, 5},
                           {7, 9, 4, 8},
                           {6, 9, 3, 7}};
        /*
        System.out.println(movieRatingAverage(ratings, 0));
        
        System.out.println(reviewerRatingAverage(ratings, 1));
        
        System.out.println(avgRating2018(ratings));
        */
        System.out.println(hardestRater2018(ratings));
        /*
        System.out.println(worstMovie2018(ratings));
        */
    }
    
    public static double movieRatingAverage(int[][] ratings, int movie){
        
        double x = 0;
        
        for(int r = 0; r < ratings.length; r++){
            x += ratings[r][movie];
        }
        
        x /= ratings.length;
        
        return x;
    }
    
    public static double reviewerRatingAverage(int[][] ratings, int reviewer){
        
        double x = 0;
        
        for(int c = 0; c < ratings[0].length; c++){
            x += ratings[reviewer][c];
        }
        
        x /= ratings[0].length;
        
        return x;
    }
    
    public static double avgRating2018(int[][] ratings){
        
        double x = 0;
        
        for(int r = 0; r < ratings[0].length; r++){
            
            for(int c = 0; c < ratings.length; c++){
                x += ratings[c][r];
            }
        }
        
        x /= ratings[0].length * ratings.length;
        
        return x;
    }
    
    public static double hardestRater2018(int[][] ratings){
        
        double x = 0;
        double avg = 10;
        double rater = 0;
        double index = 0;
        
        for(int r = 0; r < ratings[0].length; r++){
            
            for(int c = 0; c < ratings.length; c++){
                x += ratings[c][r];
                
                rater = r;
            }
            
            x /= ratings.length;
            
            if(x < avg){
                avg = x;
                
                index = rater;
            }
        }
        
        return index;
    }
    
    public static double worstMovie2018(int[][] ratings){
        
        double x = 0;
        double avg = 10;
        double movie = 0;
        double index = 0;
        
        for(int c = 0; c < ratings.length; c++){
            
            for(int r = 0; r < ratings[0].length; r++){
                x += ratings[c][r];
                
                movie = r;
            }
            
            x /= ratings[0].length;
            
            if(x < avg){
                avg = x;
                
                index = movie;
            }
        }
        
        return index;
    }
}
