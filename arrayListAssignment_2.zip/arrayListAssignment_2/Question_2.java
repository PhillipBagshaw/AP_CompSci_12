import java.util.ArrayList;

public class Question_2{
    public static void main(String[] args){
        ArrayList<Integer> list = new ArrayList<Integer>();
        
        int n = 100;
        
        for(int x = 2; x <= n; x++){
            list.add(x);
        }
        
        for (int i = 4; i <= 100; i += 2) {
            goldbachSum(i);
        }
    }
    
    public static ArrayList<Integer> primeFinder(int n){
        int p = 0;
        
        ArrayList<Integer> nums = new ArrayList<Integer>();
        
        for(int x = 2; x <= n; x++){
            nums.add(x);
        }
        
        for(int i = 0; i < nums.size(); i++){
            
            for(p = nums.size()-1; p > 0; p--){
                if(nums.get(p) > nums.get(i) && nums.get(p) % nums.get(i) == 0){
                    nums.remove(p);
                }
            }
            
        }
        
        return nums;
    }
    
    public static void goldbachSum(int n){
        ArrayList<Integer> nums =  primeFinder(100);
        
        for(int pA = 2; pA < nums.size(); pA++){
            if(nums.contains(n - pA)){
                int pB = n - pA;
                System.out.println(pA +  " + " + pB + " = " + n);
                return;
            }
        }
    }
}
