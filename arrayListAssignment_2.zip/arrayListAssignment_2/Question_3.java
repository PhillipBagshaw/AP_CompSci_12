import java.util.ArrayList;

class Question_3{
    public static void main(String[] args){
        ArrayList<Integer> n1 = new ArrayList<Integer>();
        
        n1.add(5);
        n1.add(5);
        n1.add(5);
        n1.add(5);
        
        ArrayList<Integer> n2 = new ArrayList<Integer>();
        
        n2.add(5);
        n2.add(5);
        n2.add(5);
        n2.add(5);
        
        ArrayList<Integer> n3 = add(n1, n2);
        
        System.out.println(n3);
    }
    
    public static ArrayList<Integer> add(ArrayList<Integer> aInt, ArrayList<Integer> bInt){
        ArrayList<Integer> sumFinal = new ArrayList<Integer>();
        
        int lastA = aInt.size()-1;
        int lastB = bInt.size()-1;
        
        int carry = 0;

        while(lastA >= 0 || lastB >= 0){
            int sum = 0;
            
            if(lastA >= 0 && lastB >= 0){
                sum = aInt.get(lastA) + bInt.get(lastB) + carry;
            }
            else if(lastA >= 0){
                sum = aInt.get(lastA) + carry;  
            }
            else if(lastB >= 0){
                sum = bInt.get(lastB) + carry;
            }
            else{  
                sum = carry;
            }

            if(sum > 9){
                carry = 1;
                sum -= 10;
            }
            else{
                carry = 0;
            }

            sumFinal.add(0, sum);
            
            lastA--;
            lastB--;
        }

        if(carry > 0){
            sumFinal.add(0, 1);
        }

        return sumFinal;
    }
}
