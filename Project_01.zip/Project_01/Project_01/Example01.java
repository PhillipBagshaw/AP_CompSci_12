import java.util.Scanner;

class Example01 {
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter 'A' and 'B'");
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.println("A: ");
        int a = sc.nextInt();
        
        System.out.println("B: ");
        int b = sc.nextInt();
        
        int c = (int)Math.sqrt(a*a + b*b);
        System.out.println("C: ");
        System.out.println(c);
        
    }
}
