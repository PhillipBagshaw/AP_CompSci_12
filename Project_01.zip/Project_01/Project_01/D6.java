import java.util.Scanner;

public class D6 {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        
        double a = Math.random();
        a *= (int)6;
        int aa = (int)a;
        System.out.println("Die Roll 1: " + aa);
        
        double b = Math.random();
        b *= (int)6;
        int bb = (int)b;
        System.out.println("Die Roll 2: " + bb);
        
        double c = Math.random();
        c *= (int)6;
        int cc = (int)c;
        System.out.println("Die Roll 3: " + cc);
        
        double d = Math.random();
        d *= (int)6;
        int dd = (int)d;
        System.out.println("Die Roll 4: " + dd);
        
        double e = Math.random();
        e *= (int)6;
        int ee = (int)e;
        System.out.println("Die Roll 5: " + ee);
        
        double f = Math.random();
        f *= (int)6;
        int ff = (int)f;
        System.out.println("Die Roll 6: " + ff);
    }
}
