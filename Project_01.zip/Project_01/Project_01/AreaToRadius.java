import java.util.Scanner;

public class AreaToRadius {
    public static void main (String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter a circle's radius:");
        double r = sc.nextInt();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.println("Here is the area for a circle with a radius of " + r + " units:");
        double A = Math.PI * Math.pow(r, 2);
        System.out.println(A);
        
    }
}
