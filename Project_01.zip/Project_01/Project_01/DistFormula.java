import java.util.Scanner;

public class DistFormula {
    public static void main (String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the 'x' value of the first coordinate:");
        int ax = sc.nextInt();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.println("Enter the 'y' value of the first coordinate:");
        int ay = sc.nextInt();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.println("Enter the 'x' value of the second coordinate:");
        int bx = sc.nextInt();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.println("Enter the 'y' value of the second coordinate:");
        int by = sc.nextInt();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        double distX = bx - ax;
        double distY = by - ay;
        double dist = Math.sqrt(Math.pow(distX, 2) + Math.pow(distY, 2));
        
        System.out.println("Your distance:");
        System.out.println(dist);
        
    }
}
