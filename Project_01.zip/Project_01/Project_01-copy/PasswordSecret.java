import java.util.Scanner;

public class PasswordSecret {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("Guess the password: ");
        
        String resp = sc.nextLine();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        if("Password".equals (resp)){
            System.out.println("Brilliant! The password is a match, now here is my secret: " + 42);
        }
        else{
            System.out.println("Hmm... that is incorrect. My secret will remain secure.");
        }
    }
}
