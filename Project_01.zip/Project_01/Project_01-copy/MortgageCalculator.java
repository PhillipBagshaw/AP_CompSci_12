import java.util.Scanner;

public class MortgageCalculator {
    public static void main (String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Investment Calculator");
        System.out.println("--------------------");
        System.out.println("");
        
        System.out.print("Enter the investment's principle amount in dollars: $");
        double P = sc.nextDouble();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.print("Enter the investment's intrest rate (between 0 and 1): ");
        double r = sc.nextDouble();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        System.out.print("Enter the number of years the investment will accumulate wealth: ");
        double n = sc.nextDouble();
        
        System.out.println("----------------------------------------");
        System.out.println("");
        
        double A = P * Math.pow(r + 1, n);
        System.out.println("This investment will be worth " + A + " after " + (int)n + " years.");
        
    }
}
