import java.util.Scanner;

public class D6 {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        
        double a = Math.random();
        a *= (int)6;
        int aa = (int)a;
        System.out.println("Die roll 1: " + aa);
        
        double b = Math.random();
        b *= (int)6;
        int bb = (int)b;
        System.out.println("Die roll 2: " + bb);
        
        double c = Math.random();
        c *= (int)6;
        int cc = (int)c;
        System.out.println("Die roll 3: " + cc);
        
        double d = Math.random();
        d *= (int)6;
        int dd = (int)d;
        System.out.println("Die roll 4: " + dd);
        
        double e = Math.random();
        e *= (int)6;
        int ee = (int)e;
        System.out.println("Die roll 5: " + ee);
        
        double f = Math.random();
        f *= (int)6;
        int ff = (int)f;
        System.out.println("Die roll 6: " + ff);
        
        double g = Math.random();
        g *= (int)6;
        int gg = (int)g;
        System.out.println("Die roll 7: " + gg);
        
        double h = Math.random();
        h *= (int)6;
        int hh = (int)h;
        System.out.println("Die roll 8: " + hh);
        
        double i = Math.random();
        i *= (int)6;
        int ii = (int)i;
        System.out.println("Die roll 9: " + ii);
        
        double j = Math.random();
        j *= (int)6;
        int jj = (int)j;
        System.out.println("Die roll 10: " + jj);
    }
}
