import java.util.Scanner;

public class GradeBot {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        String grade = "A";
        
        System.out.println("Grade Calculator");
        System.out.println("--------------------");
        System.out.println("");
        
        
        double score = sc.nextDouble();
    }
}
