import java.util.ArrayList;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class Puzzle{
   
   String guesses = "";
   String word = "PASSWORD";
   String wordCheck = "PASSWORD";
   
   public Puzzle(){
   }
   
   public boolean isUnsolved(){
       for(int i = 0; i < word.length(); i++){
           if(!guesses.contains("" + word.charAt(i))){
               return true;
           }
       }
       
       return false;
   }
   
   public void show(){
       System.out.print("Puzzle: ");
       
       int i = 0;
       
       while(i < word.length()){
           if(guesses.contains("" + word.substring(i, i+1))){
               System.out.print(word.substring(i, i+1) + " ");
           }
           else{
               System.out.print("_ ");
           }
           
           i++;
       }
       
       System.out.print("\n\nGuesses: ");
       
       int x = 0;
       
       while(x < guesses.length()){
           System.out.print(guesses.charAt(x));
           
           x++;
           
           if (x != guesses.length()){
               System.out.print(", ");
           }
       }
   }
   
   public boolean makeGuess(String guess){
       guess = guess.toUpperCase();
       
       guesses += guess;
       
       return word.contains(guess);
   }
   
   public String getWord(){
       return word;
   }
}
