public class Ex_1 {
    public static void main(String args){
        int i = 100;
        
        while(i >= 10){
            i--;
        }
    }
}
