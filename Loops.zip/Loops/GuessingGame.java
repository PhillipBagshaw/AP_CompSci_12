import java.util.Scanner;

public class GuessingGame{
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        int x = (int) (Math.random() * 100) + 1;
        int a  = 0;
        int atmp  = 0;
        
        System.out.println("I've picked a random number between 1 and 100. Try to guess it! ");
        
        while (a != x){
            
            System.out.print("What is your guess? ");
            a = sc.nextInt();
            
            atmp++;
            
            if (a < x){
                System.out.println("Too low!");
            }
            
            else if (a > x){
                System.out.println("Too high!");
            }
        }
        
        System.out.println("You've guessed my number! Good job!  It only took you " + atmp + " tries.");
    }
}
