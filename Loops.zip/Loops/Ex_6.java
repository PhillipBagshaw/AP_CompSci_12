import java.util.Scanner;

public class Ex_6{
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        int total = 0;
        String resp = ("y");
        
        while(resp.equals("y")){
            
            System.out.print("How many rolls do you want? ");
            int a = sc.nextInt();
            
            for(int i = 0; i <= a; i++){
                double x = Math.random();
                x *= (int)6;
                int xx = (int)x;
                System.out.print(xx);
                total += xx;
                
            }
            
            System.out.println("");
            
            System.out.println("Total: " + total);
            
            System.out.println("");
            
            System.out.print("Again? (y/n): ");
            resp = sc.next();
            
        }
    }
}
