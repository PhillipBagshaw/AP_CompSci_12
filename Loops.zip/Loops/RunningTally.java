import java.util.Scanner;

public class RunningTally {
    public static void main(String[] args) {
        double a = 0;
        double total = 0;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Let's add some numbers! [Type a negative number to quit]");
        
        while(a >= 0){
            a = sc.nextDouble();
            
            System.out.println("Add " + a);
            
            total += a;
            
            System.out.println("Total: " + total);
        }
    }
}
