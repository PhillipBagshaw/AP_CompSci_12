import java.util.Scanner;

public class Bar {
    public static void main(String[] args) {
        int i = 0;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("What characters would you like the bar to consist of? ");
        String a = sc.nextLine();
        
        System.out.println("How long would you like your bar? ");
        double x = sc.nextDouble();
        
        while(i <= x){
            System.out.print(a);
            
            i++;
        }
    }
}
