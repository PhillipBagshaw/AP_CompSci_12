import java.util.Scanner;

public class Triangle{
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("What character would you like the triangle to consist of? ");
        String a = sc.nextLine();
        
        System.out.print("How tall do you want your triangle to be? ");
        int x = sc.nextInt();
        
        for(int i = 0; i <= x; i++){
            for(int n = 0; n <= i; n++){
                System.out.print(a);
            }
            System.out.println();
        }
    }
}
