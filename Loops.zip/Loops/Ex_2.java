public class Ex_2{
    public void main(String args){
        int i;
        int j;
        for (i = 1; i <= 10; i++){
            for (j = 1 ; j <= i; j++){
                System.out.print(j + " ");
            }
            System.out.println("");
        }
    }
}
