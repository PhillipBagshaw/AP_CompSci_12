verse("duck", "quack");
