
-It Prints:
No, I wug.
You wugga wug.
I wug.

-Sequence:
void Main "No, I"
void Main ->
void zoop ->
void baffle "wug"
void baffle ->
void ping "."
<-
<-
void zoop "You wugga "
void zoop ->
void baffle "wug"
void baffle ->
void ping "."
<-
<-
<-
void Main "I "
void Main ->
void baffle "wug "
void baffle ->
void ping "."
