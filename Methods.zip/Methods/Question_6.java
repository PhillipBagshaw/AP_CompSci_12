import java.util.Scanner;

public class Question_6 {
    public static void main(String[] args){
        displayBox(10, 6);
    }
    
    public static void displayBox(int a, int b){
        for(int i = 0; i < b; i++){
            for(int n = 0; n < a; n++){
                System.out.print("$");
            }
            System.out.println("");
        }
    }
}
