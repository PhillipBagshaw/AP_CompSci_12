

Old Macdonald had a farm, EE-I-EE-I-O,
And on that farm he had a cow, EE-I-EE-I-O,
With a moo, moo here and a moo, moo there
Here a moo, there a moo, everywhere a moo, moo
Old Macdonald had a farm, EE-I-EE-I-O.
 
Old Macdonald had a farm, EE-I-EE-I-O,
And on that farm he had a dog, EE-I-EE-I-O,
With a woof, woof here and a woof, woof there
Here a woof there a woof everywhere a woof, woof
Old Macdonald had a farm, EE-I-EE-I-O.
 
