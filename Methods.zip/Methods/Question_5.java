The program will run up to the end of ping, then jump to baffle, and then loop
endlessly between ping and baffle.