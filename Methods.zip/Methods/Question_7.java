import java.util.Scanner;

public class Question_7{
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        int dieCount = 0;
        int dieFaces = 0;
        int roll = 0;
        int total = 0;
        
        String resp = "y";
        
        while(resp.equals("y")){
            
            System.out.print("How many dice do you want to roll? ");
            dieCount = sc.nextInt();
            
            System.out.print("How many sides do these dice have? ");
            dieFaces = sc.nextInt();
            
            System.out.println("");
            
            System.out.print("You rolled: ");
            total = 0;
            
            for(int i = 0; i < dieCount; i++){
                roll = rollDie(dieFaces);
                total += roll;
                System.out.print(roll + " ");
            }
            
            System.out.println("");
            
            System.out.println("Total: " + total);
            
            System.out.println("");
            
            System.out.print("Again? [y,n] ");
            resp = sc.next();
            
            System.out.println(""); 
        }
    }
    
    public static int rollDie(int n){
        
        return (int)(Math.random() * n) + 1;
        
    }
}
