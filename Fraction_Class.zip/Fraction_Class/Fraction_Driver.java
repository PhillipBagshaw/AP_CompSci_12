
public class Fraction_Driver{
    public static void main(String[] args){
        Fraction f1 = new Fraction();
        Fraction f2 = new Fraction();
        Fraction f3 = new Fraction("3/5");
        Fraction f4 = new Fraction(2, 5);
        
        /*
        int x1 = f1.getNum();
        int x2 = f2.getNum();
        int x3 = f3.getNum();
        int x4 = f4.getNum();
        */
        
       /*
        System.out.println(f1);
        System.out.println(f2);
        System.out.println(f3);
        System.out.println(f4);
        */
        
        Fraction product = Fraction.subtract(f3, f4);
        
        System.out.println(product);
    }
}
