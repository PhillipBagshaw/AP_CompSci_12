class Fraction{
    private int n, d;
    
    Fraction(){
        this.n = 4;
        this.d = 8;
    }
    
    Fraction(int n, int d){
        this.n = n;
        
        if(d == 0){
            System.out.println("--ERROR[denominator set to zero]--");
            d = 1;
        }
        
        else{
            this.d = d;
        }
    }
    
    Fraction(String f){
        int fSlash = f.indexOf("/");
        
        String num = f.substring(0, fSlash);
        String den = f.substring(fSlash+1);
        
        this.n = Integer.parseInt(num);
        
        if(den.equals("0")){
            System.out.println("--ERROR[denominator set to zero]--");
            den = "1";
        }
        
        else{
            this.d = Integer.parseInt(den);
        }
    }
    
    public Fraction(Fraction f){
        this.n = f.n;
        this.d = f.d;
    }
    
    public int getNum(){
        return this.n;
    }
    
    public int getDenum(){
        return this.d;
    }
    
    public String toString(){
        String fraction = new String();
        
        return fraction + this.n + "/" + this.d;
    }
    
    public double toDouble(){
        return (double)this.n / (double)this.d;
    }
    
    public void reduce(){
        int LCM = 0;
        int x = n;
        int y = d;
        
        while(x != y){
            if(x > y){
                x -= y;
                LCM = x;
            }
            else if(y > x){
                y -= x;
                LCM = y;
            }
        }
        
        n /= LCM;
        d /= LCM;
    }
    
    public void setNum(int x){
        this.n = x;
    }
    
    public void setDenom(int y){
        this.d = y;
    }
    
    public static Fraction multiply(Fraction a, Fraction b){
        int numerator = a.n * b.n;
        int denominator = a.d * b.d;
        
        Fraction product = new Fraction(numerator, denominator);
        product.reduce();
        
        return product;
    }
    
    public static Fraction divide(Fraction a, Fraction b){
        int numerator = a.n * b.d;
        int denominator = a.d * b.n;
        
        Fraction quotient = new Fraction(numerator, denominator);
        quotient.reduce();
        
        return quotient;
    }
    
    public static Fraction add(Fraction a, Fraction b){
        int referenceA = b.d;
        int referenceB = a.d;
        
        a.LCM(a, referenceA);
        b.LCM(b, referenceB);
        
        int numerator = a.n + b.n;
        int denominator = a.d;
        
        Fraction sum = new Fraction(numerator, denominator);
        sum.reduce();
        
        return sum;
    }
    
    public static Fraction subtract(Fraction a, Fraction b){
        int newNum = a.n * b.d - b.n * a.d;
        int newDen = a.d * b.d;
        
        Fraction ans = new Fraction(newNum, newDen);
        
        ans.reduce();
        
        return ans;
    }
    
    public void LCM(Fraction x, int ref){
        x.n *= ref;
        x.d *= ref;
    }
}
